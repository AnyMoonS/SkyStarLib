 S1=[];
 for r=0.5:0.5:2 
     k=r*10;
     dangle=2*pi/k; 
     beta=0:dangle:2*pi-0.01; 
     S1=[S1;r*cos(beta') r*sin(beta')];
 end
 dangle=2*pi/5; 
 beta=0:dangle:2*pi-0.01;
 S2=[0.5*cos(beta') 0.5*sin(beta')]+3.5; 
 S=[S1;S2]; 
 [id,m]=KMeanslClustering(S,2); 
 i=find(id==1); 
 plot(S(i,1),S(i,2),'ko','MarkerFaceColor','k');
 hold on;
 i=find(id==2);
 plot(S(i,1),S(i,2),'kx','LineWidth',2,'MarkerFaceColor','k','MarkerSize',10);